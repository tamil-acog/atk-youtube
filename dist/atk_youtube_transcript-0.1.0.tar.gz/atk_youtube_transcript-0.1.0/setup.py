# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['atk_youtube_transcript']

package_data = \
{'': ['*']}

install_requires = \
['langchain>=0.0.123,<0.0.124',
 'requests>=2.28.2,<3.0.0',
 'typer>=0.7.0,<0.8.0',
 'youtube-transcript-api>=0.5.0,<0.6.0']

entry_points = \
{'console_scripts': ['atk-youtube-transcript = '
                     'atk_youtube_transcript.transcript:main']}

setup_kwargs = {
    'name': 'atk-youtube-transcript',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
